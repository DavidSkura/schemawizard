# schemawizard

Reads a csv and generates a table design for Postgres, MySQL or BigQuery