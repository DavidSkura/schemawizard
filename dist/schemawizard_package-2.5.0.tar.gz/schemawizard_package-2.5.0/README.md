# schemawizard

Reads a csv and generates a table design for Postgres, MySQL, sqlite or BigQuery

### install with pip
pip install schemawizard-package

### command line test
py -m schemawizard_package.schemawizard

### Methods
https://github.com/daveskura/schemawizard/blob/main/methods.md

